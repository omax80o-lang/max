رنّة خلخال - قالب سلة برو (نسخة جاهزة للرفع)
تم الإنشاء: 2025-10-30 02:28 UTC

تعليمات سريعة:
1) أنشئ Repository جديد في GitHub باسم renna-khalkhal-theme.
2) ارفع ملفات هذا المجلد إلى الفرع main.
3) ادخل portal.salla.dev -> My Themes -> Create Theme -> اربط المستودع واختر الفرع main.
4) افتح 'Explore Environment' لتعديل الملفات في Twilight ثم Publish.
لتعديل مفاتيح API وإعدادات الضرائب، افحص ملف config.json.
دعم: omax80o@gmail.com
